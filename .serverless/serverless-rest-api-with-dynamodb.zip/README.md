<!--
title: Documenting Your Serverless REST API With Swagger (OpenAPI) Specification
description: An example API provided by the Serverless framework to use an example of how to document your API with Swagger and eventually use it to build a mobile app in Dropsource.
layout: Doc
-->
# Documenting Your Serverless REST API With Swagger (OpenAPI) Specification
This code is the starting point for the how-to found on the Dropsource Blog: https://www.dropsource.com/blog/serverless-rest-api/


